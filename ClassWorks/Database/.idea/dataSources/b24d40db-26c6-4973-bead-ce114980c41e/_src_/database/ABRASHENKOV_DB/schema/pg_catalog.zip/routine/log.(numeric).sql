create function pg_catalog.log(numeric) returns numeric
LANGUAGE SQL
AS $$
select pg_catalog.log(10, $1)
$$;
